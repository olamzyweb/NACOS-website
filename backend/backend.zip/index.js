import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import rateLimit from 'express-rate-limit';
import axios from 'axios';
import paymentRoutes from './routes/payment.routes.js';
import authRoutes from './routes/auth.routes.js';
import adminAuthRoutes from './routes/admin-auth.routes.js';
import studentRoutes from './routes/student.routes.js';
import contentRoutes from './routes/content.routes.js';
import servicesRoutes from './routes/services.routes.js';
import contactRoutes from './routes/contact.routes.js';
import adminRoutes from './routes/admin.routes.js';
import BirthdayService from './services/birthday.service.js';


// Pulling in our environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Trust the Render proxy to allow express-rate-limit to see the real user IP
app.set('trust proxy', 1);

/**
 * SECURITY RATE LIMITING
 * ---------------------------------------------------------
 * Stops attackers from spamming our API or brute-forcing logins.
 */
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again after 15 minutes.'
});

const authLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10, // Limit each IP to 10 login attempts per hour
  message: 'Too many login attempts. Take a break and try again later.'
});

/**
 * MIDDLEWARE SETUP
 * ---------------------------------------------------------
 * We want this to be secure and readable. 
 * Helmet helps with basic security headers, 
 * Morgan logs our requests so we know what's happening.
 */
app.use(helmet({ crossOriginResourcePolicy: false })); // Stay safe out there, but let images load!
app.use(cors());   // Allow our frontend to talk to us
app.use(express.json({ limit: '10kb' })); // Security: Limit JSON body size to prevent DoS
app.use(morgan('dev'));  // Log requests to the console
app.use(limiter); // Apply general rate limit to all requests

// Start Birthday Service (Daily checks)
BirthdayService.start();

// Root route for health checks (prevents 404 on Render/deployment pings)
app.get('/', (req, res) => {
  res.status(200).send('NACOS LASUSTECH API is running.');
});

/**
 * THE CORE ROUTES
 * ---------------------------------------------------------
 * I'll keep these clean. We'll eventually move these into a 
 * separate routes folder once the project grows.
 */

// Registering modular routes
app.use('/api/auth', authLimiter, authRoutes);
app.use('/api/admin-auth', authLimiter, adminAuthRoutes);
app.use('/api/student', studentRoutes);
app.use('/api/content', contentRoutes);
app.use('/api/services', servicesRoutes);
app.use('/api/contact', contactRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/payments', paymentRoutes);

// Serve uploads folder statically
import path from 'path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// A simple health check to make sure the lights are on
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'up', 
    timestamp: new Date().toISOString(),
    message: 'NACOS LASUSTECH Backend is humming along nicely.'
  });
});

// Diagnostic Ping to Central System
app.get('/api/ping-central', async (req, res) => {
  try {
    const start = Date.now();
    // Using POST because we know the server responds to POST
    const response = await axios.post('https://nacosid.tmb.it.com/api.php?action=login', 
      { matric_number: '000', password: '000' },
      {
        timeout: 5000,
        headers: { 
          'X-API-KEY': process.env.ID_SYSTEM_API_KEY || 'NACOS_LASUSTECH_SECURE_API_KEY',
          'Content-Type': 'application/json'
        }
      }
    );
    res.json({
      status: 'success',
      latency: `${Date.now() - start}ms`,
      central_response: response.data
    });
  } catch (error) {
    res.status(502).json({
      status: 'error',
      message: 'Could not reach central system',
      error: error.message,
      code: error.code
    });
  }
});

/**
 * ERROR HANDLING
 * ---------------------------------------------------------
 * Every good backend engineer knows that things WILL go wrong.
 * Let's catch those errors gracefully so the server doesn't crash.
 */
app.use((err, req, res, next) => {
  console.error('🔥 CRITICAL ERROR:', err.stack);
  res.status(500).json({ 
    error: 'Internal Server Error',
    message: 'Something went sideways on our end. We are looking into it!' 
  });
});

// Fire it up!
app.listen(PORT, () => {
  console.log(`
  --------------------------------------------------
  ✨ NACOS LASUSTECH Backend Started
  🌍 Server: http://localhost:${PORT}
  🛠️  Mode: ${process.env.NODE_ENV || 'development'}
  --------------------------------------------------
  `);
});
